// A simple data module
const students = [
  { id: 1, name: "Ravi", branch: "CSE" },
  { id: 2, name: "Priya", branch: "ECE" },
  { id: 3, name: "Arjun", branch: "MECH" }
];

module.exports = students; // CommonJS export
