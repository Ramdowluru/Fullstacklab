const express = require('express');
const students = require('./data/student');
const path = require('path');

const app = express();
const PORT = 3000;

// Serve static CSS files from "public" folder
app.use(express.static(path.join(__dirname, 'public')));

// Home route with HTML + CSS
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Student API</title>
        <link rel="stylesheet" href="/style.css">
      </head>
      <body>
        <h1>Welcome to the Student API!</h1>
        <p>Use <a href="/students">/students</a> to see all students.</p>
      </body>
    </html>
  `);
});

// All students
app.get('/students', (req, res) => {
  res.json(students);
});

// Single student by ID
app.get('/students/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const student = students.find(s => s.id === id);

  if (student) res.json(student);
  else res.status(404).send('Student not found');
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
