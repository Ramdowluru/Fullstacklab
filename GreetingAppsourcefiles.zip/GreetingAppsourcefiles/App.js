import React from 'react';
import Greeting from './Greeting';
import GreetingClass from './GreetingClass';

function App() {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>React Components Demo</h1>

      <h3>Functional Component:</h3>
      <Greeting />

      <h3>Class Component:</h3>
      <GreetingClass />
    </div>
  );
}

export default App;
