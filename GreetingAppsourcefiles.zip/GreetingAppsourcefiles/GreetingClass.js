import React, { Component } from 'react';

class GreetingClass extends Component {
  constructor(props) {
    super(props);
    this.state = { name: 'Ram' };
  }

  changeName = () => {
    this.setState({ name: 'Draupadi' });
  };

  render() {
    return (
      <div>
        <h2>Hello, {this.state.name}!</h2>
        <button onClick={this.changeName}>Change Name</button>
      </div>
    );
  }
}

export default GreetingClass;
