import React, { useState } from 'react';

function Greeting() {
  const [name, setName] = useState('Krishna');

  return (
    <div>
      <h2>Hello, {name}!</h2>
      <button onClick={() => setName('Draupadi')}>Change Name</button>
    </div>
  );
}

export default Greeting;
